/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/he/currency",{HKD_displayName:"\u05d3\u05d5\u05dc\u05e8 \u05d4\u05d5\u05e0\u05d2 \u05e7\u05d5\u05e0\u05d2\u05d9",CHF_displayName:"\u05e4\u05e8\u05e0\u05e7 \u05e9\u05d5\u05d5\u05d9\u05e6\u05e8\u05d9",JPY_symbol:"JP\u00a5",CAD_displayName:"\u05d3\u05d5\u05dc\u05e8 \u05e7\u05e0\u05d3\u05d9",HKD_symbol:"HK$",CNY_displayName:"\u05d9\u05d5\u05d0\u05df \u05e8\u05e0\u05de\u05d9\u05e0\u05d1\u05d9 \u05e1\u05d9\u05e0\u05d9",USD_symbol:"US$",AUD_displayName:"\u05d3\u05d5\u05dc\u05e8 \u05d0\u05d5\u05e1\u05d8\u05e8\u05dc\u05d9",
JPY_displayName:"\u05d9\u05df \u05d9\u05e4\u05e0\u05d9",CAD_symbol:"CA$",USD_displayName:"\u05d3\u05d5\u05dc\u05e8 \u05d0\u05de\u05e8\u05d9\u05e7\u05d0\u05d9",EUR_symbol:"\u20ac",CNY_symbol:"CN\u00a5",GBP_displayName:"\u05dc\u05d9\u05e8\u05d4 \u05e9\u05d8\u05e8\u05dc\u05d9\u05e0\u05d2",GBP_symbol:"\u00a3",AUD_symbol:"A$",EUR_displayName:"\u05d0\u05d9\u05e8\u05d5"});
