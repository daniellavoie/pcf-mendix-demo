/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/en-gb/currency",{USD_symbol:"$",CAD_symbol:"CA$",GBP_displayName:"British Pound",GBP_symbol:"\u00a3",HKD_symbol:"HK$",AUD_symbol:"AU$",CNY_symbol:"CN\u00a5",EUR_symbol:"\u20ac"});
