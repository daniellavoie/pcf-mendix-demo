/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/ro/currency",{HKD_displayName:"dolar din Hong Kong",CHF_displayName:"franc elve\u021bian",JPY_symbol:"JPY",CAD_displayName:"dolar canadian",HKD_symbol:"HKD",CNY_displayName:"yuan renminbi chinezesc",USD_symbol:"USD",AUD_displayName:"dolar australian",JPY_displayName:"yen japonez",CAD_symbol:"CAD",USD_displayName:"dolar american",CNY_symbol:"CNY",GBP_displayName:"lir\u0103 sterlin\u0103",GBP_symbol:"GBP",AUD_symbol:"AUD",EUR_displayName:"euro"});
