/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/el/currency",{HKD_displayName:"\u0394\u03bf\u03bb\u03ac\u03c1\u03b9\u03bf \u03a7\u03bf\u03bd\u03b3\u03ba \u039a\u03bf\u03bd\u03b3\u03ba",CHF_displayName:"\u03a6\u03c1\u03ac\u03b3\u03ba\u03bf \u0395\u03bb\u03b2\u03b5\u03c4\u03af\u03b1\u03c2",JPY_symbol:"JP\u00a5",CAD_displayName:"\u0394\u03bf\u03bb\u03ac\u03c1\u03b9\u03bf \u039a\u03b1\u03bd\u03b1\u03b4\u03ac",HKD_symbol:"HK$",CNY_displayName:"\u0393\u03bf\u03c5\u03ac\u03bd \u039a\u03af\u03bd\u03b1\u03c2",USD_symbol:"$",AUD_displayName:"\u0394\u03bf\u03bb\u03ac\u03c1\u03b9\u03bf \u0391\u03c5\u03c3\u03c4\u03c1\u03b1\u03bb\u03af\u03b1\u03c2",
JPY_displayName:"\u0393\u03b9\u03b5\u03bd \u0399\u03b1\u03c0\u03c9\u03bd\u03af\u03b1\u03c2",CAD_symbol:"CA$",USD_displayName:"\u0394\u03bf\u03bb\u03ac\u03c1\u03b9\u03bf \u0397\u03a0\u0391",EUR_symbol:"\u20ac",CNY_symbol:"CN\u00a5",GBP_displayName:"\u039b\u03af\u03c1\u03b1 \u03a3\u03c4\u03b5\u03c1\u03bb\u03af\u03bd\u03b1 \u0392\u03c1\u03b5\u03c4\u03b1\u03bd\u03af\u03b1\u03c2",GBP_symbol:"\u00a3",AUD_symbol:"A$",EUR_displayName:"\u0395\u03c5\u03c1\u03ce"});
