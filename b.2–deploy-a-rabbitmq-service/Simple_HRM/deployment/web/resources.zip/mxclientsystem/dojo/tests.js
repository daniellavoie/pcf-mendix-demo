//This file is the command-line entry point for running the tests in
//Rhino and Spidermonkey.

/*=====
dojo.tests = {
	// summary:
	//		D.O.H. Test files for Dojo unit testing.
};
=====*/

load("dojo.js");
load("tests/runner.js");
tests.run();
